/**
 *  ? Proxy Pattern --
 *    -- It allows you to use one object known as proxy as a placeholder to another object
 *    -- Proxy can control access to the object
 *    -- Instead of using the object directly - we use proxy and proxy uses that object
 * 
 *   Why we want to use Proxy object ->
 *   Ans -> to add extra functionality
 */

function CarPrice(){

    this.getPirce = _type => {
        console.log('external API call');
        switch(_type) {
            case 'tata' :
                return '20 Lakh'
            case 'mahindra' :
                return '28 Lakh'
            case 'bmw' :
                return '2 Crore'
        }

    }
}

const carAPI = new CarPrice()
// to many APIs calls
// carAPI.getPirce('tata') //external API call
// carAPI.getPirce('mahindra') //external API call
// carAPI.getPirce('bmw') //external API call
// carAPI.getPirce('tata') //external API call
// carAPI.getPirce('mahindra') //external API call
// carAPI.getPirce('bmw') //external API call
// carAPI.getPirce('tata') //external API call
// carAPI.getPirce('mahindra') //external API call
// carAPI.getPirce('bmw') //external API call
// carAPI.getPirce('tata') //external API call
// carAPI.getPirce('mahindra') //external API call
// carAPI.getPirce('bmw') //external API call
// carAPI.getPirce('tata') //external API call
// carAPI.getPirce('mahindra') //external API call
// carAPI.getPirce('bmw') //external API call

//to fix the same API call many times, we use proxy pattern

function carPriceProxy(){
    this.price = {}
    this.api = new CarPrice()
    console.log('price', this.price)
    this.getPirce = _type => {
        switch(_type){
            default :
              if(this.price[_type]){
                return this.price[_type]
              } else {
                this.price[_type] = this.api.getPirce(_type)
                return this.price[_type];
              }
        }
    }
}

const getCarPriceWithProxy = new carPriceProxy()
getCarPriceWithProxy.getPirce('tata')
getCarPriceWithProxy.getPirce('mahindra')
getCarPriceWithProxy.getPirce('bmw')
getCarPriceWithProxy.getPirce('tata')
getCarPriceWithProxy.getPirce('mahindra')
getCarPriceWithProxy.getPirce('bmw')
getCarPriceWithProxy.getPirce('tata')
getCarPriceWithProxy.getPirce('mahindra')
getCarPriceWithProxy.getPirce('bmw')
getCarPriceWithProxy.getPirce('tata')
getCarPriceWithProxy.getPirce('mahindra')
getCarPriceWithProxy.getPirce('bmw')
getCarPriceWithProxy.getPirce('tata')
getCarPriceWithProxy.getPirce('mahindra')
getCarPriceWithProxy.getPirce('bmw')


/**
 * ? Retry design pattern
 *   -- It allows you to gracefully handle temporary failure in your application --> Whenever you are making external network calls like APIs
 *   -- It basically retry any failed operations in your application and improve the overall stability and resilience
 *  Retry strategies -
 *  1. Don't retry
 *      Ex - Authentication failures -> No need to retry
 *  2. retry immediately
 *      Ex - network packet becomes corrupted in the middle of request and it fails --> immediate retry (because chances of same failure happening again is highly unlikely )
 *  3. retry after delay  --> It could be Fixed time delay or exponential back off where each retry delay gets longer and longer
 *      Ex-  When sever is busy managing plethora of requests
 */

 class RetryOperations{
    #maxRetries = 100;
    constructor(_externalCall, _retryDelay = 100){
        // this.#maxRetries = _maxRetries
        this.retryCall()
    }

    async retryCall(){
        while(this.#maxRetries > 0) {
            console.log('this.#maxRetries', this.#maxRetries)
            try{
                //external call
                _externalCall()
                console.log('success')
                break;
            } catch (error) {
                --this.#maxRetries
                console.warn(`Failed attempt ${100 - this.#maxRetries}`)
            }
            await delay(_retryDelay)
        }
    }
}

const delay = async _delay => {
    return new Promise(resolve => {
        setTimeout(()=> {
            resolve()
        }, _delay)
    })
}

function apiCall(){
    const _random = Math.random();
    console.log('_random', _random)
    if(_random < 0.05){
        return true
    } else {
        throw 'error'
    }
}
const _retryDelay = 10; //delay in millisecond
const _retry = new RetryOperations(apiCall, _retryDelay)