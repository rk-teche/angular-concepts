/**
 * Behavioural Pattern -
 * 
 */

/**
 * Strategy Pattern -
 * 
 */
 function Fedex(){
     this.calculate = _pack => {
         //some calculation
         return 2.45
     }
 }

 function DHL(){
     this.calculate = _pack => {
         //some calculation
         return 1.78
     }
 }

 const fedex = new Fedex()
 const dhl = new DHL()

 const package = { from : 'Auraiya', to: 'Delhi', weight: 1.56}
 fedex.calculate(package) //2.45
 DHL.calculate(package) //1.78