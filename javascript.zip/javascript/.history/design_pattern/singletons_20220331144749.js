/**
 * ? Singletons: when you only want single instance of class
 */
