/**
 * Behavioural Pattern -
 * 
 */

/**
* 1.Strategy pattern - This pattern define the `family of algorithms`, encapsulate each one and make them interchangeable
*    -- Strategy let's the algorithm vary independently from client that use it

   In Simple words --> there are bunch of algorithm and each one of them are interchangeable
   and whosoever is using that algorithm is not forced to change --> whenever algorithm changes
 
  UML Arrow Sign --
    --> (has-a)  - composition
    ==> (is-a) - inheritance
   */


    //this is an interface -> So it's not instantiatable
    class Car {
        constructor() {
            
        }
 
         noOfWheels(){
             return 4;
         }
         
         isLuxury(){
             return true
         }
    }
 
    class Audi extends Car {
      constructor(){
          this.noOfWheels()
      }
    }
 
    class Suzuki extends Car {
     constructor(){
         this.isLuxury() // there is no use of this method --> If I do any changes in `parent class`, this child classes might suffer
     }
    }
 
 
 function Fedex(){
     this.calculate = _pack => {
         //some calculation
         return 2.45
     }
 }

 function DHL(){
     this.calculate = _pack => {
         //some calculation
         return 1.78
     }
 }

 const fedex = new Fedex()
 const dhl = new DHL()

 const package = { from : 'Auraiya', to: 'Delhi', weight: 1.56}
 
//we have to write different shipping for each company
 fedex.calculate(package) //2.45
 dhl.calculate(package) //1.78

 //to Fix this -> we use strategy pattern
 function Shipping(){
     this.setStrategy = _company => {
         this.company = _company;
         return this
     }
     this.calculate = _package => {
        return this.company.calculate(_package)
     }
 }

 const _shipping = new Shipping()
 _shipping.setStrategy(fedex).calculate(package)
 _shipping.setStrategy(dhl).calculate(package)
