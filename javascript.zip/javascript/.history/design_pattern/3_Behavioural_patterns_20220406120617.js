/**
 * Behavioural Pattern -
 * 
 */

/**
 * Strategy Pattern -
 * 
 */
 function Fedex(){
     this.calculate = _pack => {
         //some calculation
         return 2.45
     }
 }

 function DHL(){
     this.calculate = _pack => {
         //some calculation
         return 1.78
     }
 }

 const fedex = new Fedex()
 const dhl = new DHL()

 const package = { from : 'Auraiya', to: 'Delhi', weight: 1.56}
 
//we have to write different shipping for each company
 fedex.calculate(package) //2.45
 dhl.calculate(package) //1.78

 //to Fix this -> we use strategy pattern
 function Shipping(){
     this.setStrategy = _company => {
         this.company = _company;
         return this
     }
     this.calculate = _package => {
        return this.company.calculate(_package)
     }
 }

 const _shipping = new Shipping()
 _shipping.setStrategy(fedex).calculate(package)
 _shipping.setStrategy(dhl).calculate(package)
 