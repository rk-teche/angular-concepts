/**
 * ? Design Pattern:
 * 1. Singletons
 * 2. Builder
 * 3. Observer Pattern 
 */

/**
 * ? Singletons: when you only want single instance of class
 */
class Sett{

}