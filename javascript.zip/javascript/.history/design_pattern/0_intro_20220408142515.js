/**
 * Design patterns ->
 *  Types -
 *    1. Creational Patterns
 *    2. Structural Patterns
 *    3. Behavioural Patterns
 */
