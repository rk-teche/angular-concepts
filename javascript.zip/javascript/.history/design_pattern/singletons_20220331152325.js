/**
 * ? Design Pattern:
 * 1. Singletons
 * 2. Builder
 * 3.  
 */

/**
 * ? Singletons: when you only want single instance of class
 */
class Sett{

}