/**
 * Behavioural Pattern -
 * 
 */

/**
* 1.Strategy pattern - This pattern define the `family of algorithms`, encapsulate each one and make them interchangeable
*    -- Strategy let's the algorithm vary independently from client that use it

   In Simple words --> there are bunch of algorithm and each one of them are interchangeable
   and whosoever is using that algorithm is not forced to change --> whenever algorithm changes
 
  UML Arrow Sign --
    --> (has-a)  - composition
    ==> (is-a) - inheritance
   */
    //this is an interface -> So it's not instantiatable
    class Car {
        constructor() {
            
        }
 
         noOfWheels(){
             return 4;
         }
         
         isLuxury(){
             return true
         }
    }
 
    class Audi extends Car {
      constructor(){
          this.noOfWheels()
      }
    }
 
    class Suzuki extends Car {
     constructor(){
         this.isLuxury() // there is no use of this method --> If I do any changes in `parent class`, this child classes might suffer
     }
    }
 
 
 function Fedex(){
     this.calculate = _pack => {
         //some calculation
         return 2.45
     }
 }

 function DHL(){
     this.calculate = _pack => {
         //some calculation
         return 1.78
     }
 }

 const fedex = new Fedex()
 const dhl = new DHL()

 const package = { from : 'Auraiya', to: 'Delhi', weight: 1.56}
 
//we have to write different shipping for each company
 fedex.calculate(package) //2.45
 dhl.calculate(package) //1.78

 //to Fix this -> we use strategy pattern
 function Shipping(){
     this.setStrategy = _company => {
         this.company = _company;
         return this
     }
     this.calculate = _package => {
        return this.company.calculate(_package)
     }
 }

 const _shipping = new Shipping()
 _shipping.setStrategy(fedex).calculate(package)
 _shipping.setStrategy(dhl).calculate(package)


 /**
  * ? 2. Iterator Pattern ->
  *      -- It allow you to loop over some collection of object
  *      -- It is common programming task to traverse and manipulate a collection of objects
  *      -- These collection may be stored as Array or something else like Tree, Graph etc.
  *      -- To traverse these collections -> you may need to access the item in the collection in certain order like front to back or back to front, depth-first and breath-first, or skip every two/three elements
  *      -- Iterator pattern allow you to define your own rules --> How to Traverse some collection of object 
  */

const _array = [1, "dev", true, {name: 'hero'}]

 // Iterate back to front
 function Iterator(_items){
     this.items = _items;
     this.index = this.items.length

     this.hasNext = _ => {
        return this.index >= 0
     }
     this.next = _ => {
        return this.index > -1 ? this.items[--this.index] : 'item is empty'
     }
     this.prev = _ => {
        return this.index > this.items.length ? this.items[--this.index] : 'item is empty'
     }
 }

 const myIterator = new Iterator(_array)
 myIterator.hasNext()

 /**
  * ? 2. Observer Pattern ->
  *      -- You define one to many dependency relationship from one Object known as `Subject` to many other objects known as the `observers`
  *      -- These observer watch the subject and wait for some signal or trigger from the subject before they run
  *      -- It is kind of reminds you an event listeners or Observable
  *      -- It is very useful when it comes to event handling system
  */

  /**
  * ? 3. Mediator Pattern ->
  *      -- It allows you to define an object known as Mediator that encapsulate and controls how some set of object interact with each other
  *      -- Object will send information to `mediator object` -> mediator object handles all of the complex logic and routing to decide where these message need to go.
  *      -- Ex- `Chat Room`
  */

  function Members(_name){
    this.name = _name;
    this.chatRoom = null
  }

  Members.prototype = {
      send: function(message, toMember){

      }
  }


  /**
  * ? 4. Visitor Pattern ->
  *      -- It provides you to add or provide new operations/method to an object without actually changing that Object
  *      -- The new functionality is kept in separate object known as visitor object
  *      -- It is useful, when you extending some library or framework
  *      -- The object you want to extend --> Also known as receiving object, It has some kind of accept method that takes in a visitor object and provides visitor object access to the different information and properties for that object
  */

  class Employee {
      constructor(_name, _salary){
        this.name = _name;
        this.salary = _salary
      }

      get getSalary() {
        return this.salary
      }

      set setSalary (_salary){
          this.salary = _salary
      }

      accept(visitorFun){
        visitorFun(this)
      }
  }

  const emp1 = new Employee('Rk', 100000)
  emp1.salary

