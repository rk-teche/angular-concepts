/**
 * Design patterns ->
 *  Types -
 *    1. Creational Patterns
 *    2. Structural Patterns
 *    3. Behaviroural Patterns
 */

/**
* 1.Strategy pattern - This pattern define the `family of algorithms`, encapsulate each one and make them interchangble
*    -- Strategy let's the algorithm vary independently from client that use it

   In Simple words --> there are bunch of algorithm and each one of them are interchangeable
   and whosoever is using that algorithm is not forced to change --> whenever algorithm changes
 
  UML Arrow Sign --
    --> (has-a)  - composition
    ==> (is-a) - inheritance
   */


    //this is an interface -> So it's not instantiateable
    class Car {
        constructor() {
            
        }
 
         noOfWheels(){
             return 4;
         }
         
         isLuxury(){
             return true
         }
    }
 
    class Audi extends Car {
      constructor(){
          this.noOfWheels()
      }
    }
 
    class Suzuki extends Car {
     constructor(){
         this.isLuxury() // there is no use of this method --> If I do any changes in `parent class`, this child classes might suffer
     }
    }
 
 
  /**
   * Creational Patterns --> These patterns are mainly all about providing object creation mechanism that promote flexibility and resuability --> Specially in situation where you have to create many different types of many different object
   * 1. Factory Design pattern
   * 2. Singleton Pattern
   **/  
 
 /**
  * 1. Factory Design pattern --> Factory is a building where things are manufactured, so a factory is just an objects that creates or manufactures different objects
  *  Why --> don't I create object on demand using `new` keyword ?
  *   Ans -> Factory allow you to handle all of your object creation in a centralized location --> so all new constructor calls littered throughout your code
  *   --> So your code become more clean and concise
  * */ 
 class Developers {
     constructor(_name){
         this.name = _name
         this.type = 'Developer'
     }
 }
 
 class Testers {
     constructor(_name){
         this.name = _name
         this.type = 'Tester'
     }
 }
 
 class EmployeeFactory {
     constructor(){
         this.create = (_name, _type) => {
             switch(_type){
                 case 1: 
                     return new Developers(_name)   
                 case 2: 
                     return new Testers(_name)
             }
         }
     }
 }
 
 const eFactory = new EmployeeFactory()
 const employees = []
 
 employees.push(eFactory.create('RK', 1))
 employees.push(eFactory.create('Himanshu', 2))
 
 function print(){
     console.log(`${this.name} and ${this.type}`)
 }
 
 for(let e of employees){
     print.call(e) // pass `e` reference to the print method
 }
 
 /**
  * 2.Singleton Design pattern --> Limit the number of instances of an object to at most 1
  * */ 
 
 const singleton = (function(){
     function ProcessManager(){
         this.numProcess = 0;
     }
     let pManager;
     function createPManager(){
         pManager = new ProcessManager()
         return pManager;
     }
 
     return { getProcessManager: () => {
         if(!pManager) {
             pManager = new ProcessManager()
         }
         return pManager
     } }
 })()
 
 const processManager1 = singleton.getProcessManager()
 const processManager2 = singleton.getProcessManager()
 
 processManager1 === processManager2 //true