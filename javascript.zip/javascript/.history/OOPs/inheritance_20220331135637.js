/**
 * Difference in syntax -
 *  1.
 */
import Square from './Classes_methods';
import { Square as SQ } from './Classes_methods';
import * as SQ from './Classes_methods';
import { default as SQU } from './Classes_methods';
// require function only available in nodeJS environment or you need to add requireJS library to run the function
// const sq = require('./Classes_methods')// create new instance

/**
 * BY `extends` keyword, Rectangle class can inherit all the global variable and methods of Square
 * Note - *Reverse inheritance is not possible
 */
class Rectangle extends Square {
    /** 
     * Overirding -> replace the parent method into the child class
     * Method over riding is possible in javascript
     * @returns
     */
    initializeCount(){
        let data = this.getDescription()
        console.log('data', data)
        // return 'Rectangle class --> method over-riding'
    }

}

let r = new Rectangle(5)