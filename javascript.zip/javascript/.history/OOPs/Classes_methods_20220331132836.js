/**
 * Class --> Object in Javascript
 * Difference between class and function -
 *  1. function declarations are hoisted but class declarations are not.
 *      --> That means you first need to declare your class and then access it, Otherwise you will get an reference error
 * It has -
 *   1. Instance Properties: What They have
 *   2. Instance Method: What They do
 */
class Square {
    color = 'red' //variables which declare in class, have global scope --> That means we can use this outside the class as well
    #isValid = false // variable with `#` symbol denote private variable --> it means I can't use this outside the class but user can see the private methods
    
    /**
     * Constructor - it provides any custom initialization that must be called before any method --> whenever our object gets instantiated
     * If you don't provide your own constructor, then a default constructor will be supplied for you.
     * If your class is base class then default constructor is empty.
     * @param {*} _width 
     */
    constructor(_width){
        if(this.#isNumber(_width)){
            this.width = _width;
            this.height = _width;
        } else {
            throw new Error('please enter valid number')
        }
    }

    /**Constructor overloading is not possible in Javascript */
    // constructor(){

    // }

    getDescription(){
        return 'function overloading' //function overloading is not possible in javascript
    }

    getDescription(){ // Typically function and method both are same, but in terms of classes it is mostly referred as methods and in terms of scripting they are refer as functions  
        console.log('description')
        return `square dimensions are ${this.width}*${this.height} and color is ${this.color} ${this.#isValid}` // we can fetch the private variable value from function
    }
    //getDescription() --> one can't directly call methods inside the class --> It would give you an error

    // setter -> In case of getter or setter we consider them as simple variable rather than methods
    set area(_area){
        this.width = Math.sqrt(_area)
        this.height = this.width;
    }

    // getter
    get area(){
        return this.width*this.height
    }

    /**
     * private Method: 
     */ 
    #isNumber(_width){
        return Number.isInteger(_width)
    }

    /**
     * Static variable --> Its value does not get re-initialized on every new instance of class
     */
    static initialize = 0;
    initializeCount(){
        console.log('count')
        return ++Square.initialize
    }

    /**
     * Static Method: Helper method, It is not a part of the instantiated object
     */
    static count(){
        return this.initialize //inside the static methods, we can access static variables directly by `this` keyword
    }
}

let s = new Square(8)

s.area //get the area
s.color //get the color
s.getDescription() //get description
s.width, s.height //get dimension

s.area = 64 //set the area

/**
 * BY `extends` keyword, Rectangle class can inherit all the global variable and methods of Square
 * Note - Reverse inheritance is not possible
 */
class Rectangle extends Square {
    /** 
     * Overirding -> replace the parent method into the child class
     * Method over riding is possible in javascript
     * @returns
     */
    initializeCount(){
        let data = this.getDescription()
        console.log('data', data)
        // return 'Rectangle class --> method over-riding'
    }

}

let r = new Rectangle(5)


/**
 * It can be imported through
 * const squ = require('./mobile') --> file path
 * const s = squ.SQA() // create new instance
 */
exports.SQA = Square;