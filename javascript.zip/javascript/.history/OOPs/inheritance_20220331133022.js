const sq = require('./Classes_methods')

class Rectangle extends sq.SQA {
    getData(){
        this.initializeCount()
    }
}