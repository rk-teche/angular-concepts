/**
 *  ? Data Structure --> way to arrange data in main memory for efficient usages
 * 
 *  ? Type of DS -
 *   1. Liner Data Structure
 *   2. Non-liner Data Structure
 *   
 */

/**
 *  ? Algorithm --> sequence of steps to solve the particular problem
 *   Ex - Sorting an Array
 *   
 */