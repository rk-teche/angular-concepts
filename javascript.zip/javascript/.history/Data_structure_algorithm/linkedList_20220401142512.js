/**
 * Associative arrays (A-Arrays) --> Combination of key value pair
 *  Note - We don't use the word index with associative arrays because we often don't worry about the order of key-value pair
 * * A-Arrays Rules -
 *  1. Key value pair are bound together
 *  2. Each key must be unique
 *  3. An A-Array is an abstract datatype
 *  3. Most A-Arrays, whether they are dictionaries, maps, or hashes --> are implemented using `Hash Table`
 *  
 *  ? Hashing --
 *     1. Hashing is a way of taking some `raw data` and mixing it together to form a smaller single piece of data
 *     2. We call the process of inputting the raw ingredients to produce the final hash value --> A Hash function
 * 
 *  ? Hash Inputs --
 *    --> Characters, Objects, Numbers
 *    -- and Hash output would be an integer
 * 
 *  ? Hash Function --
 *    -- Hash function are not reversible, they are one way - This means you can't feed the hash value into another function and get the original data back.
 *    Ex - Whenever website stores username and password, they stored password in the hash value format
 *             Ex - Simplistic example would be ASCII code conversion of any text
 *    Note - Anytime two input produce the same hash value.
 * 
 */