/**
 * ? Set(): 
 *   1. Collection of unique item
 *   2. Order doesn't matter --> 
 *          Often, we don't even want to retrieve a piece of data --> That's why we don't have index, key or anything specific to look up the value
 *   3. None of the element are duplicated
 */

const primaryColors = new Set();
primaryColors.add('red')
primaryColors.add('green')
primaryColors.add('blue')

primaryColors.has('yellow') // false

primaryColors.entries() // return iterable entries

Object.freeze(primaryColors) // in javascript till now (April 2022) --> One can't freeze the sets

/**
 * ? Set() vs WeakSet()
 */

/**
 * ? Map()
 * 
 */


/**
 * ? map() vs WeakMap()
 */