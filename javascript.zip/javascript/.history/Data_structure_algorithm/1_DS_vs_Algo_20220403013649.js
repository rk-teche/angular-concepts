/**
 * Data Structure --> way to arrange data in main memory for efficient usages
 */