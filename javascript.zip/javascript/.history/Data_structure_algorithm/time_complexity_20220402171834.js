/**
 * ? Time Complexity --
 * 
 */

while (true){ // O(log n)

}

for (let i; i<10; i++ ){ // O(n)

}