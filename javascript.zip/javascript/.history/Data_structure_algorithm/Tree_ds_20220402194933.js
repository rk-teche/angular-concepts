/**
 * ? Tree 
 *   -- different Data Structure (DS) that is not sequential like stacks, queues, array
 *   -- It is an abstracted instructor that simulates a hierarchical tree structure like family tree
 *   -- Top most node -> Root Node
 *   -- Node which does not contain child -> Leaf Node
 *   -- Nodes have parent child relationship
 *   -- Each child node is essentially a sub-tree --> that means, it may contains its own child nodes
 */