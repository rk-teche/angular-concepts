// Throw error in Javascript

/**
 * Stack - First in Last Out (FILO) or Last In First out (LIFO)
 * Stack methods - push(), pop(), peer(), length(), empty(), search()
 */

class Stack {
    #top = -1;
    #stack = [];
    constructor(_maxLength = 100){
        this.stackLimit = _maxLength; 
        if(!this.#isInteger(this.stackLimit)){
            throw new Error('Max length must be an integer')
        }
    }

    get length(){
        return this.#top + 1
    }

    push(data){
        if(!data) return this.length;

        if(this.#top < this.stackLimit){
            this.#stack.push(data)
            this.#top++

            return this.length
       } else {
            throw new Error('stack overflow')
       }
    }

    getStack(){
        return this.#stack.toString()
    }

    peer(){
        let peerStack = () => this.#stack[this.#top] 
        this.#isStackEmpty(peerStack);
    }

    pop(){
        let _popStack = () => {
            this.#stack.pop()
            this.#top-- 
            return this.length;
        }
        this.#isStackEmpty(_popStack);
    }

    #isStackEmpty(_cb){
        if(this.#top < 0){
           return console.warn('Stack is empty');
        } else {
            return _cb()
        }
    }


    #isInteger(_num){
       return Number.isInteger(_num)
    }

    
}

let s = new Stack()