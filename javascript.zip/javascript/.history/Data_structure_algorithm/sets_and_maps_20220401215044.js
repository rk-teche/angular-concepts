/**
 * ? Sets: 
 *   1. Collection of unique item
 *   2. Order doesn't matter --> 
 *          Often, we don't even want to retrieve a piece of data --> That's why we don't have index, key or anything specific to look up the value
 *   3. None of the element are duplicated
 */