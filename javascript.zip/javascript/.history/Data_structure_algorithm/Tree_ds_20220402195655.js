/**
 * ? Tree 
 *   -- different Data Structure (DS) that is not sequential like stacks, queues, array
 *   -- It is an abstracted instructor that simulates a hierarchical tree structure like family tree
 *   -- Top most node -> Root Node
 *   -- Node which does not contain child -> Leaf Node
 *   -- Nodes have parent child relationship
 *   -- Each child node is essentially a sub-tree --> that means, it may contains its own child nodes
 *   -- Every node above a node is called --> ancestor nodes and
 *   -- Every node below the node is called --> descendant nodes
 *   -- Both Ancestors and descendant nodes are measure in depth (Call all the way from root or leaf node)
 *
 *  ? Type of Trees -
 *   1. Un-Ordered Tree - it means order of the node are not important
 *          --> Ex: 1.Dom Tree, 2. File System in your computer
 * 
 *   2. Ordered Tree -
 *          
 * ? Trees Example -
 *     * OOPs programming is pretty much creating trees with classes with single inheritance and all classes have pretty much nodes
 *     * Dom Tree
 */