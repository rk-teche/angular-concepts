class Stack {
    #top = -1;
    constructor(_maxLength = 100){
        if(!Number.isInteger(_maxLength)){
            console.error('Max length must be a integer')
            return;
        }
        this._stack = [];
    }

    get length(){
        return top
    }

    push(data){
        if(top < maxLength){
            this._stack.push(data);
            top++
       } else {
           return `stack overflow`
       }
    }

    pop(){
        this._stack.pop()
        top--  
    }
    
}

let myStack = new Stack()