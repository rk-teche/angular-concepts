// Throw error in Javascript

/**
 * Stack - First in Last Out (FILO)
 * Stack methods - push(), pop(), peer(), length()
 */

class Stack {
    #top = -1;
    #stack = [];
    constructor(_maxLength = 100){
        this.stackLimit = _maxLength; 
        if(!this.#isInteger(this.stackLimit)){
            throw new Error('Max length must be an integer')
        }
    }

    get length(){
        return this.#top + 1
    }

    push(data){
        if(this.#top < this.stackLimit){
            this.#stack.push(data)
            this.#top++
       } else {
            throw new Error('stack overflow')
       }
    }

    getStack(){
        let _getStack = () => {
            this.#stack.toString()
        }
        return this.#isStackEmpty(_getStack);
    }

    peer(){
        let peerStack = () => {
            this._stack[this.#top+1] 
        }
        this.#isStackEmpty(peerStack);
    }

    pop(){
        let popStack = () => {
            this._stack.pop()
            this.#top--  
        }
        this.#isStackEmpty(popStack);
    }

    #isStackEmpty(_cb){
        if(this.#top < 0){
           return console.warn('No items in Stack');
        } else {
            return _cb()
        }
    }


    #isInteger(_num){
       return Number.isInteger(_num)
    }

    
}

let m = new Stack()