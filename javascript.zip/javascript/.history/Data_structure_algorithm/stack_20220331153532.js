// Throw error in Javascript

/**
 * Stack - First in Last Out (FILO)
 * Stack methods - push(), pop(), peer(), length()
 */

class Stack {
    #top = -1;

    constructor(_maxLength = 100){
        if(!this.#isInteger(_maxLength)){
            throw new Error('Max length must be an integer')
        }
        this._stack = [];
    }

    get length(){
        return top+1
    }

    push(data){
        if(top < maxLength){
            this._stack.push(data);
            top++
       } else {
           return `stack overflow`
       }
    }

    pop(){
        this._stack.pop()
        top--  
    }


    #isInteger(_num){
       return Number.isInteger(_num)
    }

    
}

let myStack = new Stack()