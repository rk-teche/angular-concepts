//! Things which need to be learned
// exportable function
// error handling
// replace through prototype
// diff between function and class
// How prototype works and prototype inheritance
// polymorphism

//? Completed Items
// private variable and methods
// use getter and setter
// How to use super() constructor


export function Stack(maxLength = 100){
    _top = -1;
    _stack = [];
    
    function push(data){
        if(_top < maxLength){
             _stack.push(data);
            _top++
        } else {
            return `stack overflow`
        }
    }

    function getStack(){
        _stack.toString()
    }

    function pop(){
        _stack.pop()
        _top--
    }

    function peer(){
        return _stack[_top]
    }

    function length(){
        return _top+1  
    }

    function empty(){
        _stack = []
        _top = -1
    }
    emptyMsg(empty);

    function isEmpty(){
        return _top <= -1
    }

    function emptyMsg(_cb){
        if(isEmpty()){
            return `Empty Stack`
        } else {
            _cb()
        }
    }

    return {
         push, pop, peer, getStack, empty, length      
    }
}

let myStack = Stack(10);

console.dir(myStack)