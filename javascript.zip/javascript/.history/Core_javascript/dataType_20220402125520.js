/**
 * ? DataType -
 *   -- Two types of data type in Javascript
 *   1. Primitive Data Type : 5 Types
 *      -- Boolean, null, undefined, string, number    
 *   2. Reference Data Type
 *      -- Array, Function, Object, Set, WeakSet, Map, WeakMap
 */