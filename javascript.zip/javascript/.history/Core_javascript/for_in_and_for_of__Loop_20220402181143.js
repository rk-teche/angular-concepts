/**
 * ? for in vs for of loop
 */

const nameObject = {first: 'R', last: 'K'}

for(let n in nameObject){ // for in loops through enumerable properties
    console.log(n);
}

for(let n of nameObject){
    console.log(n); // ! Note -> Javascript `Object` is not iterable --> use `for in loop`
}

const _array = [1,3,4]
for(let a of _array){
    console.log(a); //Arrays are iterable 
}