/**
 * 
 */

let myObj1 = {
    twitter: 'Youth for nation',
    email: 'youth4nation1947@gmail.com'
}
myObj1['twitter'] = 'your value 1' //easily writable

let myObj2 = {};
Object.defineProperties(myObj2, {
    twitter : {
        value: 'Youth for nation',
    },
    email : {
        value: 'youth4nation1947@gmail.com'
    }
})

myObj2['twitter'] = 'your value 2' // not writable

let myObj3 = {};
Object.defineProperty(myObj3, 'holiday', {
    value: 'Andaman Nicobar',
})

myObj3['holiday'] = 'Lakshadweep' // not writable by default
myObj3['new destination'] = 'Lakshadweep' // can add new properties

Object.defineProperty(myObj3, 'tour', {
    value: 'Yatra.com',
    writable: true,
})

myObj3['tour'] = 'makemytrip';

/**
 * ! Q. What is difference among, Object -> writable, enumerable, configurable
 * * Ans - Read this out - https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperty
 */


/**
 * ? Object.create() method
 */
let profile = {
    firstName : 'Rk',
    LastName : 'P',
    get fullName() {
        return `${this.firstName} ${this.LastName}`
    }
};
let developerProfile = Object.create(profile) // set `profile` object properties in the prototype of `developerProfile` object
developerProfile.__proto__ === profile //true

let engineerProfile = Object.create(profile, { // add `experience` properties along with profile as prototype chain
    experience : {value: '5 years'}
})


function Beverages(_name, _temperature){
    this.name = _name;
    this.temperature = _temperature
}

Beverages.prototype.drink = function(){
    return `I'm drinking ${this.name}`
}

function Coffee(_type){
    this.type = _type
}

Coffee.prototype = new Beverages('Latte Coffee', 55) // Add Beverages in prototype
Coffee.prototype = Object.create(Beverages) // Add Beverages in prototype

Coffee.prototype.isAvailable = function(_pinCode){
    if(_pinCode === 1) return `${this.name} coffee available`
    return `not available`
}

