/**
 * 
 */

let myObj1 = {
    twitter: 'Youth for nation',
    email: 'youth4nation1947@gmail.com'
}
myObj1['twitter'] = 'your value 1' //easily writable

let myObj2 = {};
Object.defineProperties(myObj, {
    twitter : {
        value: 'Youth for nation'
    },
    email : {
        value: 'youth4nation1947@gmail.com'
    }
})

myObj2['twitter'] = 'your value 2' // not writable