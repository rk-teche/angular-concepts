/**
 * 
 */

let myObj = {};
Object.defineProperties(myObj, {
    twitter : {
        value: 'Youth for nation',
        writable: true
    },
    email : {
        value: 'youth4nation1947@gmail.com'
    }
})