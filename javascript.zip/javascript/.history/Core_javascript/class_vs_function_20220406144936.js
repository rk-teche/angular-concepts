//! Things which need to be learned
// exportable function
// error handling
// replace through prototype
// diff between function and class
// How prototype works and prototype inheritance
// polymorphism

//? Completed Items
// private variable and methods
// use getter and setter
// How to use super() constructor


/**
 * ? ASCII Code 
 *  -- Numerical representation of text characters
 *  -- 
 * 
 */
export function Stack(maxLength = 100){
    _top = -1;
    _stack = [];
    
    function push(data){
        if(_top < maxLength){
             _stack.push(data);
            _top++
        } else {
            return `stack overflow`
        }
    }

    function getStack(){
        _stack.toString()
    }

    function pop(){
        _stack.pop()
        _top--
    }

    function peer(){
        return _stack[_top]
    }

    function length(){
        return _top+1  
    }

    function empty(){
        _stack = []
        _top = -1
    }
    emptyMsg(empty);

    function isEmpty(){
        return _top <= -1
    }

    function emptyMsg(_cb){
        if(isEmpty()){
            return `Empty Stack`
        } else {
            _cb()
        }
    }

    return {
         push, pop, peer, getStack, empty, length      
    }
}

let myStack = Stack(10);

console.dir(myStack)


/**
 * Difference between `use of prototype and functions inside a class`
 * Difference
 *   -- Class.method = function () { }
 *   -- Class.prototype.method = function () {  }
 * 
 * Ans -> One big difference is that methods/properties added via prototype are only stored once (objects “containing” the prototype just “reference” the method/property) whereas methods/properties added in the constructor are parsed and copied for each instance created by that constructor.
 */

// ! Not Answered
class Car {
  is4X4Drive(){
      return true
  }
}

Car.prototype.is360Camera = type => {
    return type === 'luxury'
}

console.dir(Car)
const rangeRover = new Car()

rangeRover.__proto__.is360Camera = _ => {
    return 'luxury'
}

/**
 * ! Difference between `__proto__ and prototype`
 */