/**
 * ? DataType -
 *   -- Two types of data type in Javascript
 *   1. Primitive Data Type : 5 Types
 *      -- Boolean, null, undefined, string, number    
 *   2. Reference Data Type
 *      -- Array, Function, Object, Set, WeakSet, Map, WeakMap -->  They are technically object, so we can refer them as Object.
 */

let x = 10;
let a = x; //primitive data types always copied by value

/**
 * ? Reference data types -
 *   -- Variables that are assigned a non-primitive value are given a reference to that value.
 *   -- That reference points to the object's location in memory, that means variables don't actually contains a value
 *   Bear with me and read this article - https://codeburst.io/explaining-value-vs-reference-in-javascript-647a975e12a0
 *  
 */

 let obj1 = {name: 'Rana'}
 let obj2 = obj1
 obj1 === obj2 //true, why -> because both variable contains same reference