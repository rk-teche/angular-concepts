// exportable function
// private variable and methods
// error handling
// use getter and setter
// replace through prototype
// diff between function and class
// What is the use of private variables - JS
// How to use super() constructor
// How prototype works and prototype inheritance
// error handling
// polymorphism


export function Stack(maxLength = 100){
    _top = -1;
    _stack = [];
    
    function push(data){
        if(_top < maxLength){
             _stack.push(data);
            _top++
        } else {
            return `stack overflow`
        }
    }

    function getStack(){
        _stack.toString()
    }

    function pop(){
        _stack.pop()
        _top--
    }

    function peer(){
        return _stack[_top]
    }

    function length(){
        return _top+1  
    }

    function empty(){
        _stack = []
        _top = -1
    }
    emptyMsg(empty);

    function isEmpty(){
        return _top <= -1
    }

    function emptyMsg(_cb){
        if(isEmpty()){
            return `Empty Stack`
        } else {
            _cb()
        }
    }

    return {
         push, pop, peer, getStack, empty, length      
    }
}

let myStack = Stack(10);

console.dir(myStack)