/**
 * 
 */

let myObj1 = {
    twitter: 'Youth for nation',
    email: 'youth4nation1947@gmail.com'
}
myObj1['twitter'] = 'your value 1' //easily writable

let myObj2 = {};
Object.defineProperties(myObj2, {
    twitter : {
        value: 'Youth for nation'
    },
    email : {
        value: 'youth4nation1947@gmail.com'
    }
})

myObj2['twitter'] = 'your value 2' // not writable

let myObj3 = {};
Object.defineProperty(myObj3, 'holiday', {
    value: 'Andaman Nicobar',
})

myObj3['holiday'] = 'Lakshadweep' // not writable
myObj3['new destination'] = 'Lakshadweep' // can add new properties

Object.defineProperty(myObj3, 'tour', {
    value: 'Yatra.com',
    writable: true
})

myObj3['tour'] = 'makemytrip';