/**
 * 
 */

const myObj = {};
Object.defineProperties(myObj, {
    twitter : {
        value: 'Youth for nation'
    },
    email : {
        value: 'youth4nation1947@gmail.com'
    }
})