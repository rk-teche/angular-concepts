/**
 * ? Greedy Algorithm :
 *  -- An approach of making the locally optimal choice at each stage with the hope of finding a global optimum.
 *  ? Pros -
 *      1. simple, easy to implement
 *      2. run fast
 *  ? Cons -
 *      -- making locally optimal choices don't always provide a globally optimum solution.
 *      -- you can't reconsider its choices 
 * 
 *  ? When should use that algorithm --
 *      1. Global optimal can be arrived at by selecting a local optimum
 *      2. An optimal solution to the problem contains an optimal solution to the sub-problems
 * 
 *  ? Applications : which use greedy algorithm
 *     1. Activity Selection Problem
 *     2. Huffman Coding
 *     3. Job Sequencing Problem
 *     4. Fractional Knapsack Problem
 *     5. Prim's Minimum Spanning tree
 */

/**
 * ? Activity Selection Problem 
 *   Problem -> given `n` activities with their start and finish times. Select the maximum number of activities that can be performed by single person,
 *           -- Assuming that a person can only work on a single activity at time.
 */