/**
 * ? Greedy Algorithm :
 *  -- An approach of making the locally optimal choice at each stage with the hope of finding a global optimum.
 *  ? Pros -
 *      1. simple, easy to implement
 *      2. run fast
 *  ? Cons -
 *      -- very often they don't provide a globally optimum solution.
 */