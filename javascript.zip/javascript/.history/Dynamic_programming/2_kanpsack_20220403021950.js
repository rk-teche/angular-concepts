/**
 * ? 0-1 Kanpsack --> 6 variations
 *  1. Subset sum
 *  2. Equal Sum Partition
 *  3. Count of Subset Sum
 *  4. Minimum Subset difference
 * 
 */