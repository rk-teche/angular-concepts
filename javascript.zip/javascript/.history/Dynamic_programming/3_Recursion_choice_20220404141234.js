/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// nums == [1,2]
function getSubSet(_numbers, depth = 0, subset = [], result = []){
    if(depth === _numbers.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(_numbers, depth + 1, subset, result)
        getSubSet(_numbers, depth + 1, [...subset, _numbers[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]