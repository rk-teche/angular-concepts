/**
 * ? Recursion:
 *   -- Make smaller I/P after every call
 *   -- Recursive Tree --> Soul of recursion
 *   -- Recursion can be implemented when we have to make choices + take a decision on the basis of these choices
 * 
 *  ! Designing a recursive a tree is important --> Code become easy to implement after that
 * 
 * ? Recursion used in -
 *   -- Data structure -> LinkedList, Tree, Graph
 *   -- Dynamic programming
 *   -- Backtracking
 *   -- Divide and conquer 
 * 
 * ? Make Input smaller:
 *   1. every time we make a decision to make the problem smaller --> That's why our input become smaller on every call
 *    -- Our Primary Goal : to take the decision
 *    -- make problem smaller
 *    -- input become smaller every time
 */

/**
 * ? How to make recursive tree
 *  * Problem -- Subset tree
 *    input -> "abc"
 *    output -> "", "a", "b", "c", "ab", "bc", "ca", "abc"   (creating a subset from input 'abc')
 * 
 *  Recursive Tree -
 *   -- number of branches === number of choices
 * 
 */

/**
 *  ? Recursion Problems
 *  * Problem based on I/P - O/P method
 *        1. print 1 to n or n to 1
 *        2. `Sort an array` And `Sort an Stack`
 *        3. Delete middle element in stack
 *        4. Count number of occurrences
 *        5. Remove duplicate from the string
 *        6. subset problem
 *        7. Permutation and spaces (variations)
 *        8. Joseplus problem
 * 
 * 
 *  * Problem based on Extended I/P - O/P method
 *        1. Binary string -> # of 1s > # of 0s
 *        2. Generate Balanced Parenthesis
 * 
 *  ? 4 Approaches to Recursion -
 *    1. Smaller the Input -> Induction + Base condition + hypothesis (IBH Method) --> Generally use to solve smaller problem
 *    2. Recursion Tree -  I/P - O/P method (When we can take the decision) --> Medium recursion problem
 *    3. Choice Diagram -- complex recursion problem
 *    4. 
 * 
 *  Design hypothesis
 *  Base condition = Smallest valid input / Smallest invalid input
 * 
 * ? Beauty of hypothesis and induction
 *   -- hypothesis --> We decided the signature of function -- means how this particular function actually works
 */

/**
 * Problem 1: print n to 1
 */
function printNum(_num){
    if(_num === 0){ //Base condition
        return;
    }
    printNum(_num - 1) //hypothesis
    console.log(_num) //induction step
}

printNum(6)

/**
 * Problem 2: print 1 to n
 */
 function printNum(_num, i = 1){
    if(i > _num){ //Base condition
        return 'Competed';
    }
    console.log(i) //induction step
    return printNum(_num, i+1) //hypothesis
}

printNum(5)

/**
 * Problem 3: Factorial number
 */
 function factorial(_num){
    if(_num === 0 || _num === 1){ //Base condition
        return 1;
    }
    return _num * factorial(_num - 1) //hypothesis
}

factorial(10) // 3628800

/**
 * ? Fibonacci series
 */

function fibonacci(_num, i = 0, j = 1){
    if(_num === 0) { //base condition
        return;
    }  
    const result = i + j;
    console.log(result);
    fibonacci(_num - 1, j, result) //hypothesis
}

fibonacci(10) //log fibonacci series upto 10 numbers


/**
 * ? Height of the Binary tree
 */

function getBTHeight(_node, root){
    if(node === 0){ // leaf node 
        return 1
    }
    return height + Math.max(getBTHeight(_leftNode), getBTHeight(_rightNode))
}

getBTHeight()


/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// nums == [1,2]
function getSubSet(_numbers, depth = 0, subset = [], result = []){
    if(depth === _numbers.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(_numbers, depth + 1, subset, result)
        getSubSet(_numbers, depth + 1, [...subset, _numbers[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]