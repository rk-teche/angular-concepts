/**
 * ? 0-1 Knapsack --> 6 variations
 *  1. Subset sum
 *  2. Equal Sum Partition
 *  3. Count of Subset Sum
 *  4. Minimum Subset sum difference
 *  5. Target Sum
 *  6. # (number) of subset with given difference
 * 
 * ? Knapsack Types
 *   1. Fractional Knapsack - Greedy Algorithm  -- Fill the items in bag even by fraction
 *   2. 0/1 Knapsack  -- Fill the either the whole item or no item in big
 *   3. unbounded Knapsack -- Multiple occurrences of same item in bag
 */

/**
 * ? 0/1 Knapsack
 * 
 */