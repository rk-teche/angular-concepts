/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// Subset along with unique subsets (using Set())
function subsets(_input = '', _output = '', _result = new Set()){ //b
    if(_input.length === 0){
        _result.add(_output)
        return _result
    }
    const _opt1 = _output;
    const _opt2 = _output+_input[0];
    _input = _input.slice(1,_input.length).trim() 

    subsets(_input, _opt1, _result)
    subsets(_input, _opt2, _result)
    return _result
}
subsets('abc') //['', 'c', 'b', 'bc', 'a', 'ac', 'ab', 'abc']

// nums == [1] -> [[], [1]]
// ! Need to fix the output
function getArraySubSet(_array = [], output = [], result = []){
    if(_array.length === 0){
        result.push(output) //
        return result
    }
    const opt1 = output //[]
    const opt2 = [...output, _array[0]] //[1]
    _array = _array.splice(1, (_array.length || 1)) //[]
    getArraySubSet(_array, opt1, result) // [], [], [] --> [[]]
    getArraySubSet(_array, opt2, result) // [], [1], [[]] --> [[], [1]]
    return result
}

// nums == [1,2]
function getSubSet(_numbers, depth = 0, subset = [], result = []){
    if(depth === _numbers.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(_numbers, depth + 1, subset, result)
        getSubSet(_numbers, depth + 1, [...subset, _numbers[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]


/**
 * Note - print subset == print power set == subset subsequence
 * ? subset subsequence (little bit different)
 *    -- Ex- (abc) => "", "a", "b", "c", "ab", "ac" "bc", "abc" //Length => 8 (but `ac` pair is not allowed --> because it's not in the sequence)
 * 
 * Evaluator can ask to print subset in lexicographical order --> alphabet order
 */

// permutation with spaces
 function permutationSpaces(_input = '', _output = '', _result = []){
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    const _opt1 = _output+_input[0];
    const _opt2 = `${ _output}_${_input[0]}`;
    _input = _input.slice(1).trim() //BC
    permutationSpaces(_input, _opt1, _result) 
    if(!_output){
        //do something!!
    } else {
        permutationSpaces(_input, _opt2, _result)
    }
    return _result;
}

permutationSpaces('ABCDE') //`16 combination -> ['ABCDE', 'ABCD_E', 'ABC_DE', 'ABC_D_E', 'AB_CDE', 'AB_CD_E', 'AB_C_DE', 'AB_C_D_E', 'A_BCDE', 'A_BCD_E', 'A_BC_DE', 'A_BC_D_E', 'A_B_CDE', 'A_B_CD_E', 'A_B_C_DE', 'A_B_C_D_E']


// permutation with case change
function permutationCaseChange(_input = '', _output = '', _result = []){
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    const _opt1 = _output+_input[0];
    const _opt2 = `${ _output}${_input[0].toUpperCase()}`;
    _input = _input.slice(1).trim() //BC
    permutationCaseChange(_input, _opt1, _result) 
    permutationCaseChange(_input, _opt2, _result)
    
    return _result;
}

permutationCaseChange('abcd') //16 combination -> ['abcd', 'abcD', 'abCd', 'abCD', 'aBcd', 'aBcD', 'aBCd', 'aBCD', 'Abcd', 'AbcD', 'AbCd', 'AbCD', 'ABcd', 'ABcD', 'ABCd', 'ABCD']


function permutationLetterCaseChange(_input = '', _output = '', _result = []){
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    let _supportOpt = _output, ifirstIdx; 
    do {
        ifirstIdx = _input[0];
        _supportOpt = _supportOpt+ifirstIdx
        _input = _input.slice(1).trim()
    } while (Number.isInteger(Number(ifirstIdx)) && _input.length > 0)

    const _opt1 = `${_supportOpt}`;
    const _opt2 = `${ _supportOpt.slice(0, _supportOpt.length - 1)}${transformLetter(ifirstIdx)}`; // a, a1B
    
    
    permutationLetterCaseChange(_input, _opt1, _result)
    if(_opt1 !== _opt2){
        permutationLetterCaseChange(_input, _opt2, _result)
    }
    
    return _result;
}

function transformLetter(_letter){
 if(_letter === _letter.toUpperCase()){
    return _letter.toLowerCase()
 } 
 return _letter.toUpperCase()
}

permutationLetterCaseChange('d1a2B09c') // 16 combinations -->  ['d1a2B09c', 'd1a2B09C', 'd1a2b09c', 'd1a2b09C', 'd1A2B09c', 'd1A2B09C', 'd1A2b09c', 'd1A2b09C', 'D1a2B09c', 'D1a2B09C', 'D1a2b09c', 'D1a2b09C', 'D1A2B09c', 'D1A2B09C', 'D1A2b09c', 'D1A2b09C']


/**
 * Balanced Parentheses
 */
 function balancedParenthesis(_num = 1){
    let openParenthesis, closeParenthesis;
    while(i === 0){
        openParenthesis = '('.concat(openParenthesis)
        closeParenthesis = ')'.concat(closeParenthesis)
    }

    findPattern(openParenthesis, closeParenthesis)
 }

 function findPattern(_openBracket, _closeBracket, _output = '', result = []){ // open - (((,  close - )))
    if(_openBracket.length === 0 && _closeBracket.length === 0 ) {
        result.push(_output)
        return result
    }
    const _opt1 = _output+_openBracket[0] // (
    _openBracket = _openBracket.slice(1, _openBracket.length)        
    const _opt2 = _output+_closeBracket[0] // )
    findPattern(_openBracket, _closeBracket, _opt1, result) // ((  ))) ( [], 
    _closeBracket = _closeBracket.slice(1, _closeBracket.length)

    if(_output && _openBracket.length && _openBracket.length !== _closeBracket.length){
        
        findPattern(_openBracket, _closeBracket, _opt2, result)
    }

    return result;
 }

 /**
  * 
  */
//  function twoSum(_array, _sumTarget, _result = []){
//     if(_array.length === 0){
//         return _result
//     }

//     const _element1 = _array.pop()
//     _element1+_array[0] === 9
//     twoSum(_array, _sumTarget, _result)
//  }