/**
 * ? Recursion:
 *   -- Make smaller I/P after every call
 *   -- Recursive Tree --> Soul of recursion
 *   -- Recursion can be implemented when we have to make choices + take a decision on the basis of these choices
 * 
 *  ! Designing a recursive a tree is important --> Code become easy to implement after that
 * 
 * ? Recursion used in -
 *   -- Data structure -> LinkedList, Tree, Graph
 *   -- Dynamic programming
 *   -- Backtracking
 *   -- Divide and conquer 
 * 
 * ? Make Input smaller:
 *   1. every time we make a decision to make the problem smaller --> That's why our input become smaller on every call
 *    -- Our Primary Goal : to take the decision
 *    -- make problem smaller
 *    -- input become smaller every time
 */

/**
 * ? How to make recursive tree
 *  * Problem -- Subset tree
 *    input -> "abc"
 *    output -> "", "a", "b", "c", "ab", "bc", "ca", "abc"   (creating a subset from input 'abc')
 * 
 *  Recursive Tree -
 *   -- number of branches === number of choices
 * 
 */

/**
 *  ? Recursion Problems
 *  * Problem based on I/P - O/P method
 *        1. print 1 to n or n to 1
 *        2. `Sort an array` And `Sort an Stack`
 *        3. Delete middle element in stack
 *        4. Count number of occurrences
 *        5. Remove duplicate from the string
 *        6. subset problem
 *        7. Permutation and spaces (variations)
 *        8. Joseplus problem
 * 
 * 
 *  * Problem based on Extended I/P - O/P method
 *        1. Binary string -> # of 1s > # of 0s
 *        2. Generate Balanced Parenthesis
 * 
 *  ? 4 Approaches to Recursion -
 *    1. Smaller the Input -> Induction + Base condition + hypothesis (IBH Method) --> Generally use to solve smaller problem
 *    2. Recursion Tree -  I/P - O/P method (When we can take the decision) --> Medium recursion problem
 *    3. Choice Diagram -- complex recursion problem
 *    4. 
 * 
 *  Design hypothesis
 *  Base condition = Smallest valid input / Smallest invalid input
 * 
 * ? Beauty of hypothesis and induction
 *   -- hypothesis --> We decided the signature of function -- means how this particular function actually works
 */

/**
 * Problem 1: print n to 1
 */
function printNum(_num){
    if(_num === 0){ //Base condition
        return;
    }
    printNum(_num - 1) //hypothesis
    console.log(_num) //induction step
}

printNum(6)

/**
 * Problem 2: print 1 to n
 */
 function printNum(_num, i = 1){
    if(i > _num){ //Base condition
        return 'Competed';
    }
    console.log(i) //induction step
    return printNum(_num, i+1) //hypothesis
}

printNum(5)

/**
 * Problem 3: Factorial number
 */
 function factorial(_num){
    if(_num === 0 || _num === 1){ //Base condition
        return 1;
    }
    return _num * factorial(_num - 1) //hypothesis
}

factorial(10) // 3628800

/**
 * ? Fibonacci series
 */

function fibonacci(_num, i = 0, j = 1){
    if(_num === 0) { //base condition
        return;
    }  
    const result = i + j;
    console.log(result);
    fibonacci(_num - 1, j, result) //hypothesis
}

fibonacci(10) //log fibonacci series upto 10 numbers


/**
 * ! Height of the Binary tree --> In Progress...
 */

function getBTHeight(_node, root){
    if(node === 0){ // leaf node 
        return 1
    }
    return height + Math.max(getBTHeight(_leftNode), getBTHeight(_rightNode))
}

getBTHeight()


/**
 * ? Sort an array : complexity - 2*N, N = length of any array
 *  2 -> 2 steps
 *  3 -> 7 steps, 4
 *  4 -> 10 steps, 6
 *  5 -> 16 steps, 11
 *  7 -> 18 steps / 11
 *  10 -> 
 *  11 -> 50 steps, 39
 * 
 */
 
// ! Time Complexity -> o(n) 
function sort(_array, i = 0){ //[1, 200, 100]
    if(_array.length === 1){ //base condition
        return _array
    } else {
     const temp = _array.pop()//hypothesis
     return insertValue(sort(_array), temp) //Induction
    }
}

// ! Time Complexity -> O(2N*LogN) --> Not correct, just close to this
function insertValue(_array, _value){ // [1, 10],  5
    if(!_value && _value !== 0) return 'Value must not be null or empty'
    if(_array.length === 0 || _value >= _array[_array.length - 1]){ //base condition
        _array.push(_value)
        return _array; 
    } else {
        const _remainingValue = _array.pop(); //hypothesis
        //Induction
        const sortedArray = insertValue(_array, _value)
        sortedArray.push(_remainingValue)
        return sortedArray //[1, 5, 10]
    } 
}

sort([-30, -50]) // [-50, -30]

function removeMidStackNode(_array){
    if(!_array || _array.length === 0) return 'Value must not be null or empty'

    const _size = _array.length;
    let _midPoint = Math.ceil(_size/2);
    // return `${_midPoint} ${_size % 2 === 0 ? _midPoint+1 : ''}`.trim()
    return removeMid(_array, _midPoint)
}

function removeMid(_array, _midPoint){
    if(_midPoint === _array.length){
        _array.pop()
        return _array
    }
    const _value = _array.pop();
    removeMid(_array, _midPoint).push(_value)
    return _array
}

// reverse using extra memory space
function reverse(_array, _newArray = []){ // [1,2]
    if(!_array) return 'Value must not be null or empty'

    if(_array.length === 0){ //base condition
        return _newArray;
    }
    _newArray.push(_array.pop()) //hypothesis
    return reverse(_array, _newArray) //induction
}

// reverse in the same array without using extra memory
function reverse(_array){ // [1,2]
    if(!_array) return 'Value must not be null or empty'

    if(_array.length === 2){ //base condition --> [2,1]
        const [first, second] = _array
        _array[1] = first
        _array[0] = second
        return _array;
    }
    const _value = _array.pop(); //hypothesis
    return [...[_value], ...reverse(_array)] //induction
}

/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// nums == [1,2]
function getSubSet(_numbers, depth = 0, subset = [], result = []){
    if(depth === _numbers.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(_numbers, depth + 1, subset, result)
        getSubSet(_numbers, depth + 1, [...subset, _numbers[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]