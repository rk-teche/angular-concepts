/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// Subset along with unique subsets (using Set())
function subsets(_input = '', _output = '', _result = new Set()){ //b
    if(_input.length === 0){
        _result.add(_output)
        return _result
    }
    const _opt1 = _output;
    const _opt2 = _output+_input[0];
    _input = _input.slice(1,_input.length).trim() 

    subsets(_input, _opt1, _result)
    subsets(_input, _opt2, _result)
    return _result
}
subsets('abc') //['', 'c', 'b', 'bc', 'a', 'ac', 'ab', 'abc']

// nums == [1] -> [[], [1]]
// ! Need to fix the output
function getArraySubSet(_array = [], output = [], result = []){
    if(_array.length === 0){
        result.push(output) //
        return result
    }
    const opt1 = output //[]
    const opt2 = [...output, _array[0]] //[1]
    _array = _array.splice(1, (_array.length || 1)) //[]
    getArraySubSet(_array, opt1, result) // [], [], [] --> [[]]
    getArraySubSet(_array, opt2, result) // [], [1], [[]] --> [[], [1]]
    return result
}

// nums == [1,2]
function getSubSet(_numbers, depth = 0, subset = [], result = []){
    if(depth === _numbers.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(_numbers, depth + 1, subset, result)
        getSubSet(_numbers, depth + 1, [...subset, _numbers[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]


/**
 * Note - print subset == print power set == subset subsequence
 * ? subset subsequence (little bit different)
 *    -- Ex- (abc) => "", "a", "b", "c", "ab", "ac" "bc", "abc" //Length => 8 (but `ac` pair is not allowed --> because it's not in the sequence)
 * 
 * Evaluator can ask to print subset in lexicographical order --> alphabet order
 */

// permutation with spaces
 function permutationSpaces(_input = '', _output = '', _result = []){
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    const _opt1 = _output+_input[0];
    const _opt2 = `${ _output}_${_input[0]}`;
    _input = _input.slice(1).trim() //BC
    permutationSpaces(_input, _opt1, _result) 
    if(!_output){
        //do something!!
    } else {
        permutationSpaces(_input, _opt2, _result)
    }
    return _result;
}

permutationSpaces('ABCDE') //`16 combination -> ['ABCDE', 'ABCD_E', 'ABC_DE', 'ABC_D_E', 'AB_CDE', 'AB_CD_E', 'AB_C_DE', 'AB_C_D_E', 'A_BCDE', 'A_BCD_E', 'A_BC_DE', 'A_BC_D_E', 'A_B_CDE', 'A_B_CD_E', 'A_B_C_DE', 'A_B_C_D_E']


// permutation with case change
function permutationCaseChange(_input = '', _output = '', _result = []){
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    const _opt1 = _output+_input[0];
    const _opt2 = `${ _output}${_input[0].toUpperCase()}`;
    _input = _input.slice(1).trim() //BC
    permutationCaseChange(_input, _opt1, _result) 
    permutationCaseChange(_input, _opt2, _result)
    
    return _result;
}

permutationCaseChange('abcd') //16 combination -> ['abcd', 'abcD', 'abCd', 'abCD', 'aBcd', 'aBcD', 'aBCd', 'aBCD', 'Abcd', 'AbcD', 'AbCd', 'AbCD', 'ABcd', 'ABcD', 'ABCd', 'ABCD']


function permutationLetterCaseChange(_input = '', _output = '', _result = []){ //a1b2, 1b2
    if(_input.length === 0){
        _result.push(_output)
        return _result 
    }
    let _supportOpt = _output, ifirstIdx; 
    do {
        ifirstIdx = _input[0]; //1, b
        _supportOpt = _supportOpt+ifirstIdx//a, a1, a1b
        _input = _input.slice(1).trim() //1b2, b2, 2
    } while (Number.isInteger(Number(ifirstIdx))) // false, true, false

    const _opt1 = `${_supportOpt}`; // a, a1b
    const _opt2 = `${ _supportOpt.slice(0, _supportOpt.length - 1)}${ifirstIdx.toUpperCase()}`; // a, a1B
    
    
    permutationLetterCaseChange(_input, _opt1, _result) // 1b2, a, [],,  
    permutationLetterCaseChange(_input, _opt2, _result) // 1b2, A, [],, 
    
    return _result;
}

permutationLetterCaseChange('a1b2') 