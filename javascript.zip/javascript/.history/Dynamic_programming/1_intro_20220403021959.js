/**
 * Dynamic Programming - https://www.youtube.com/watch?v=nqowUJzG-iM&list=PL_z_8CaSLPWekqhdCPmFohncHwz8TY2Go
 *  
 *  ? DP is nothing but a `enhanced recursion`
 *    -- DP introduced to improve the recursion execution
 *    -- Whenever their is overlapping problem in recursion -> then we use DP
 * 
 *  ? How to identify DP --
 *    1. Choice - whether we need to include it or not
 *    2. Optimal things can be asked 
 *        Ex - Maximum profit in stock 
 * 
 *  ? Approach --
 *    1. first Write Recursive solution ---> 
 *    2. then try to Memoize ---> 
 *    3. if not work then use `Top-down approach` --> Tabulation
 * 
 * 
 *  ? DP Famous Parent Problems --
 *   1. 0-1 Kanpsack --> 6 variations
 *   2. Unbounded Kanpsack --> 5 variations
 *   3. Fibonacci --> 7 variations
 *   4. LCS (Longest Common Subsequence) --> 15 variations
 *   5. LIS (Longest Increasing Subsequence) --> 10 variations
 *   6. Kadane' Algorithm --> 6 variations
 *   7. Matrix Chain Multiplication --> 7 variations
 *   8. DP on Trees --> 4 variations
 *   9. DP on Grid --> 14 variations
 *  10. Others --> 5 variations
 */