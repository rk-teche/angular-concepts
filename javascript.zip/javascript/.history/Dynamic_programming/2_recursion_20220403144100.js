/**
 * ? Recursion:
 *   -- Make smaller I/P after every call
 *   -- Recursive Tree --> Soul of recursion
 *   -- Recursion can be implemented when we have to make choices + take a decision on the basis of these choices
 * 
 *  ! Designing a recursive a tree is important --> Code become easy to implement after that
 * 
 * ? Recursion used in -
 *   -- Data structure -> LinkedList, Tree, Graph
 *   -- Dynamic programming
 *   -- Backtracking
 *   -- Divide and conquer 
 * 
 * ? Make Input smaller:
 *   1. every time we make a decision to make the problem smaller --> That's why our input become smaller on every call
 *    -- Our Primary Goal : to take the decision
 *    -- make problem smaller
 *    -- input become smaller every time
 */

/**
 * ? How to make recursive tree
 *  * Problem -- Subset tree
 *    input -> "abc"
 *    output -> "", "a", "b", "c", "ab", "bc", "ca", "abc"   (creating a subset from input 'abc')
 * 
 *  Recursive Tree -
 *   -- number of branches === number of choices
 * 
 */

/**
 *  ? Recursion Problems
 *  * Problem based on I/P - O/P method
 *        1. print 1 to n or n to 1
 *        2. `Sort an array` And `Sort an Stack`
 *        3. Delete middle element in stack
 *        4. subset problem
 *        5. Remove duplicate from the string
 *        6. Count number of occurrences
 *        7. Permutation and spaces (variations)
 *        8. Joseplus problem
 * 
 * 
 *  * Problem based on Extended I/P - O/P method
 *        1. Binary string -> # of 1s > # of 0s
 *        2. Generate Balanced Parenthesis
 * 
 *  ? 4 Approaches to Recursion -
 *    1. Recursion Tree -  I/P - O/P method (When we can take the decision)
 *    2. Smaller the Input -> Base condition + Induction + hypothesis
 *    3. Choice Diagram
 */


/**
 * Problem 1: print 1 to n or n to 1
 */

function printNum(_num){
    if(_num === 0){
        //
    } else {
        console.log(_num)
        printNum(_num - 1)
    }
}

printNum(5)



/**
 * I/P --> "ab"
 * O/P --> "", "a", "b", "ab"
 */

// nums == [1,2]
function getSubSet(nums, depth = 0, subset = [], result = []){
    if(depth === nums.length && subset.length > 0){
        result.push(subset)
    } else {
        getSubSet(nums, depth + 1, subset, result)
        getSubSet(nums, depth + 1, [...subset, nums[depth]], result)
        return result
    }
}

getSubSet([1,2]) // [[], [1], [2], [1,2]]