/**
 * ? Recursion:
 *   -- Make smaller I/P after every call
 *   -- Recursive Tree --> Soul of recursion
 *   -- Recursion can be implemented when we have to make choices + take a decision on the basis of these choices
 * 
 *  ! Designing a recursive a tree is important --> Code become easy to implement after that
 * 
 * 
 * ? Make Input smaller:
 *   1. every time we make a decision to make the problem smaller --> That's why our input become smaller on every call
 *    -- Our Primary Goal : to take the decision
 *    -- make problem smaller
 *    -- input become smaller every time
 */