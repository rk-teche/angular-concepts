/**
 * ? 0-1 Knapsack --> 6 variations
 *  1. Subset sum
 *  2. Equal Sum Partition
 *  3. Count of Subset Sum
 *  4. Minimum Subset sum difference
 *  5. Target Sum
 *  6. # (number) of subset with given difference
 * 
 * ? Knapsack Types
 *   1. Fractional Knapsack - Greedy Algorithm  -- Fill the items in bag even by fraction
 *   2. 0/1 Knapsack  -- Fill the either the whole item or no item in big
 *   3. unbounded Knapsack -- Multiple occurrences of same item in bag
 */

/**
 * ? 0/1 Knapsack
 *  -- Base Condition -> Think of the smallest valid input
 *  -- Choice Diagram
 */

// return max value sum
function knapsackMaxValue(_weightArray = [], _valueArray = [], maxWeight = 0){
    if(_weightArray.length === 0 || maxWeight === 0){
        return 0;
    }

    if(maxWeight >= _weightArray.at(-1)){
        const _weight = _weightArray.pop()
        const _value = _valueArray.pop()
        return Math.max(
            _value + knapsackMaxValue(_weightArray, _valueArray, maxWeight - _weight),
            knapsackMaxValue(_weightArray, _valueArray, maxWeight)
        )
    } else {
        _weightArray.pop()
        _valueArray.pop()
        return knapsackMaxValue(_weightArray, _valueArray, maxWeight)
    }
} //15

// return array of max values
function knapsackMaxValue(_weightArray = [], _valueArray = [], maxWeight = 0, value = 0, result = []){
    if(maxWeight === 0 || _weightArray.length === 0){
        return value
    }

    if(maxWeight >= _weightArray.at(-1)){
        const _weight = _weightArray.pop()
        const _value = _valueArray.pop()
        result.push(
            Math.max(
                knapsackMaxValue(_weightArray, _valueArray, maxWeight - _weight, _value, result),
                knapsackMaxValue(_weightArray, _valueArray, maxWeight, 0, result)
            )
        )
    } else {
        _weightArray.pop()
        _valueArray.pop()
        result.push(knapsackMaxValue(_weightArray, _valueArray, maxWeight, 0, result))
    }
    return result;
} // [5, 10]

// return index of max values
function knapsackMaxValue(_weightArray = [], _valueArray = [], maxWeight = 0, value = 0, result = []){
    if(maxWeight === 0 || _weightArray.length === 0){
        return value
    }

    if(maxWeight >= _weightArray.at(-1)){
        const _weight = _weightArray.pop()
        const _value = _valueArray.pop()
        result.push(
            Math.max(
                knapsackMaxValue(_weightArray, _valueArray, maxWeight - _weight, _value, result),
                knapsackMaxValue(_weightArray, _valueArray, maxWeight, 0, result)
            )
        )
    } else {
        _weightArray.pop()
        _valueArray.pop()
        result.push(knapsackMaxValue(_weightArray, _valueArray, maxWeight, 0, result))
    }
    return result;
} // [0,2]

knapsackMaxValue([4,4,1], [5,2,10], 5)