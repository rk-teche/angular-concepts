myModule = require('./01_file_system')

console.log('myModule', myModule)
console.log('text ==>', myModule.myText)