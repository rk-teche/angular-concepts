_ = require("lodash");

console.log(_)
console.log(_.random(1, 100))
console.log(_.random(1, 100))